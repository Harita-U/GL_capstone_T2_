from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)
model = pickle.load(open('model_pickle.pkl', 'rb'))

@app.route("/")
def home():
	return "hi home page"

@app.route("/model", methods=['GET'])
def model():
	int_features = [int(x) for x in request.form.values()]
	final_features = [np.array(int_features)]
	prediction = model.predict(final_features)
	output = round(prediction[0], 2)
	return render_template('index.html', prediction_text='House price will be $ {}'.format(output))
	#return render_template('index.html')

if __name__ == '__main__':
	app.run(debug=True)

